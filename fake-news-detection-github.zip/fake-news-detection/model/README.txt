Trained model files are generated here when you run:
python train_model.py

Generated .pkl files are excluded from Git by .gitignore. Anyone cloning the repository must add the dataset and train the model locally.
