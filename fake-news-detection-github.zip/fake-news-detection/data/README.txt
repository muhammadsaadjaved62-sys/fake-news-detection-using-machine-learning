Place the dataset files in this folder:
- Fake.csv
- True.csv

The common Kaggle Fake and Real News dataset uses these filenames and includes a 'text' column.
Do not commit large datasets to GitHub unless you have checked the dataset license and GitHub file-size limits.
